// Kernel counting semaphores for Assignment 7, xv6-public (x86).
#include "types.h"
#include "defs.h"
#include "param.h"
#include "spinlock.h"

#define NSEMAPHORES 10

struct semaphore {
  int value;
  int initialized;
  struct spinlock lock;
};

static struct semaphore semaphores[NSEMAPHORES];
static struct spinlock semtable_lock;

void
seminit(void)
{
  int i;
  initlock(&semtable_lock, "semtable");
  for(i = 0; i < NSEMAPHORES; i++) {
    semaphores[i].value = 0;
    semaphores[i].initialized = 0;
    initlock(&semaphores[i].lock, "semaphore");
  }
}

int
sem_init_kernel(int sem_id, int value)
{
  struct semaphore *s;
  if(sem_id < 0 || sem_id >= NSEMAPHORES || value < 0)
    return -1;

  acquire(&semtable_lock);
  s = &semaphores[sem_id];
  acquire(&s->lock);
  // The interface requires initialization before users start waiting/signaling.
  // Reinitialization is safe only when the semaphore has no active waiters.
  s->value = value;
  s->initialized = 1;
  release(&s->lock);
  release(&semtable_lock);
  return 0;
}

int
sem_wait_kernel(int sem_id)
{
  struct semaphore *s;
  if(sem_id < 0 || sem_id >= NSEMAPHORES)
    return -1;
  s = &semaphores[sem_id];
  acquire(&semtable_lock);
  if(!s->initialized) {
    release(&semtable_lock);
    return -1;
  }
  release(&semtable_lock);

  acquire(&s->lock);
  // Dijkstra P(): the value may become negative to count blocked waiters.
  s->value--;
  if(s->value < 0)
    sleep(s, &s->lock);
  release(&s->lock);
  return 0;
}

int
sem_signal_kernel(int sem_id)
{
  struct semaphore *s;
  if(sem_id < 0 || sem_id >= NSEMAPHORES)
    return -1;
  s = &semaphores[sem_id];
  acquire(&semtable_lock);
  if(!s->initialized) {
    release(&semtable_lock);
    return -1;
  }
  release(&semtable_lock);

  acquire(&s->lock);
  s->value++;
  // wakeup_one() is required here because xv6's normal wakeup() wakes every
  // sleeper on a channel, while a counting-semaphore V() should grant one.
  if(s->value <= 0)
    wakeup_one(s);
  release(&s->lock);
  return 0;
}
