#!/usr/bin/env python3
"""Apply Assignment 7 changes to a clean MIT xv6-public (x86) source tree.

Usage: python3 apply_assignment7.py /path/to/xv6-public
The script intentionally targets xv6-public/master, not xv6-riscv.
"""
from pathlib import Path
import re
import shutil
import sys


def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise ValueError(f"{label}: expected one occurrence of a patch marker, found {count}: {old!r}")
    return text.replace(old, new, 1)


def replace_regex_once(text, pattern, repl, label, flags=0):
    updated, count = re.subn(pattern, repl, text, count=1, flags=flags)
    if count != 1:
        raise ValueError(f"{label}: expected one regex match, found {count}: {pattern!r}")
    return updated


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 apply_assignment7.py /path/to/xv6-public", file=sys.stderr)
        return 2

    root = Path(sys.argv[1]).resolve()
    bundle = Path(__file__).resolve().parent
    required = ["proc.c", "proc.h", "vm.c", "defs.h", "sysproc.c",
                "syscall.c", "syscall.h", "user.h", "usys.S", "trap.c", "Makefile"]
    missing = [name for name in required if not (root / name).is_file()]
    if missing:
        print("Not an xv6-public source root; missing: " + ", ".join(missing), file=sys.stderr)
        return 2

    files = {name: (root / name).read_text() for name in required}

    # proc.h: process/thread and scheduler metadata.
    files["proc.h"] = replace_once(
        files["proc.h"],
        "  char name[16];               // Process name (debugging)\n",
        "  char name[16];               // Process name (debugging)\n"
        "  int is_thread;                // Created by clone(), shares pgdir\n"
        "  int priority;                 // 1 is highest; 20 is lowest\n"
        "  int wait_ticks;               // RUNNABLE ticks since last scheduled\n",
        "proc.h")

    # defs.h: internal kernel interfaces.
    files["defs.h"] = replace_once(
        files["defs.h"],
        "void            yield(void);\n",
        "void            yield(void);\n"
        "int             clone(void (*fcn)(void *), void *arg, void *stack);\n"
        "int             join(void);\n"
        "int             set_priority(int pid, int priority);\n"
        "int             get_priority(int pid);\n"
        "void            scheduler_tick(void);\n"
        "void            wakeup_one(void *chan);\n"
        "void            vmrefinit(void);\n"
        "int             sharevm(pde_t *pgdir);\n"
        "void            freevmref(pde_t *pgdir);\n"
        "void            seminit(void);\n"
        "int             sem_init_kernel(int sem_id, int value);\n"
        "int             sem_wait_kernel(int sem_id);\n"
        "int             sem_signal_kernel(int sem_id);\n",
        "defs.h")

    # syscall numbers, dispatcher declarations/table, user stubs/declarations.
    files["syscall.h"] = replace_once(
        files["syscall.h"], "#define SYS_close  21\n",
        "#define SYS_close  21\n"
        "#define SYS_clone  22\n"
        "#define SYS_join   23\n"
        "#define SYS_sem_init 24\n"
        "#define SYS_sem_wait 25\n"
        "#define SYS_sem_signal 26\n"
        "#define SYS_set_priority 27\n"
        "#define SYS_get_priority 28\n", "syscall.h")

    files["syscall.c"] = replace_once(
        files["syscall.c"], "extern int sys_close(void);\n",
        "extern int sys_close(void);\n"
        "extern int sys_clone(void);\n"
        "extern int sys_join(void);\n"
        "extern int sys_sem_init(void);\n"
        "extern int sys_sem_wait(void);\n"
        "extern int sys_sem_signal(void);\n"
        "extern int sys_set_priority(void);\n"
        "extern int sys_get_priority(void);\n", "syscall.c declarations")
    files["syscall.c"] = replace_once(
        files["syscall.c"], "[SYS_close]  sys_close,\n",
        "[SYS_close]  sys_close,\n"
        "[SYS_clone]  sys_clone,\n"
        "[SYS_join]   sys_join,\n"
        "[SYS_sem_init] sys_sem_init,\n"
        "[SYS_sem_wait] sys_sem_wait,\n"
        "[SYS_sem_signal] sys_sem_signal,\n"
        "[SYS_set_priority] sys_set_priority,\n"
        "[SYS_get_priority] sys_get_priority,\n", "syscall.c table")

    files["user.h"] = replace_once(
        files["user.h"], "int uptime(void);\n",
        "int uptime(void);\n"
        "int clone(void (*fcn)(void *), void *arg, void *stack);\n"
        "int join(void);\n"
        "int sem_init(int sem_id, int value);\n"
        "int sem_wait(int sem_id);\n"
        "int sem_signal(int sem_id);\n"
        "int set_priority(int pid, int priority);\n"
        "int get_priority(int pid);\n", "user.h")

    files["usys.S"] = replace_once(
        files["usys.S"], "SYSCALL(uptime)\n",
        "SYSCALL(uptime)\n"
        "SYSCALL(clone)\n"
        "SYSCALL(join)\n"
        "SYSCALL(sem_init)\n"
        "SYSCALL(sem_wait)\n"
        "SYSCALL(sem_signal)\n"
        "SYSCALL(set_priority)\n"
        "SYSCALL(get_priority)\n", "usys.S")

    # System call argument unmarshalling.
    files["sysproc.c"] += r'''

// Assignment 7 system-call wrappers.
int
sys_clone(void)
{
  int fcn, arg, stack;
  if(argint(0, &fcn) < 0 || argint(1, &arg) < 0 || argint(2, &stack) < 0)
    return -1;
  return clone((void (*)(void *))fcn, (void *)arg, (void *)stack);
}

int
sys_join(void)
{
  return join();
}

int
sys_sem_init(void)
{
  int sem_id, value;
  if(argint(0, &sem_id) < 0 || argint(1, &value) < 0)
    return -1;
  return sem_init_kernel(sem_id, value);
}

int
sys_sem_wait(void)
{
  int sem_id;
  if(argint(0, &sem_id) < 0)
    return -1;
  return sem_wait_kernel(sem_id);
}

int
sys_sem_signal(void)
{
  int sem_id;
  if(argint(0, &sem_id) < 0)
    return -1;
  return sem_signal_kernel(sem_id);
}

int
sys_set_priority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  return set_priority(pid, priority);
}

int
sys_get_priority(void)
{
  int pid;
  if(argint(0, &pid) < 0)
    return -1;
  return get_priority(pid);
}
'''

    # Add the kernel semaphore object and user test executables.
    files["Makefile"] = replace_once(
        files["Makefile"], "\tproc.o\\\n",
        "\tproc.o\\\n\tsem.o\\\n", "Makefile kernel objects")
    files["Makefile"] = replace_once(
        files["Makefile"], "\t_zombie\\\n",
        "\t_zombie\\\n"
        "\t_threadtest\\\n"
        "\t_synctest\\\n"
        "\t_deadlock\\\n"
        "\t_priotest\\\n", "Makefile user programs")

    # proc.c initialization / allocproc defaults.
    files["proc.c"] = replace_once(
        files["proc.c"], '  initlock(&ptable.lock, "ptable");\n',
        '  initlock(&ptable.lock, "ptable");\n'
        "  vmrefinit();\n"
        "  seminit();\n", "proc.c pinit")
    files["proc.c"] = replace_once(
        files["proc.c"], "  p->pid = nextpid++;\n",
        "  p->pid = nextpid++;\n"
        "  p->pgdir = 0;\n"
        "  p->sz = 0;\n"
        "  p->parent = 0;\n"
        "  p->cwd = 0;\n"
        "  p->killed = 0;\n"
        "  p->is_thread = 0;\n"
        "  p->priority = 10;\n"
        "  p->wait_ticks = 0;\n"
        "  memset(p->ofile, 0, sizeof(p->ofile));\n"
        "  p->name[0] = 0;\n", "proc.c allocproc defaults")

    # growproc updates the size metadata for every proc that shares this pgdir.
    grow_start = files["proc.c"].index("int\ngrowproc(int n)\n{")
    grow_end = files["proc.c"].index("// Create a new process copying p as the parent.", grow_start)
    grow = files["proc.c"][grow_start:grow_end]
    grow = replace_once(grow, "  struct proc *curproc = myproc();\n",
                        "  struct proc *curproc = myproc();\n  struct proc *p;\n", "proc.c growproc declaration")
    grow = replace_once(grow, "  curproc->sz = sz;\n  switchuvm(curproc);\n",
                        "  acquire(&ptable.lock);\n"
                        "  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)\n"
                        "    if(p->state != UNUSED && p->pgdir == curproc->pgdir)\n"
                        "      p->sz = sz;\n"
                        "  release(&ptable.lock);\n"
                        "  switchuvm(curproc);\n", "proc.c growproc size propagation")
    files["proc.c"] = files["proc.c"][:grow_start] + grow + files["proc.c"][grow_end:]

    # clone(): same pgdir, independent kernel stack/trapframe and a user stack frame.
    clone_code = r'''// Create a kernel-supported thread sharing the caller's address space.
// stack is the page-aligned BASE of a user stack page allocated by the caller.
int
clone(void (*fcn)(void *), void *arg, void *stack)
{
  int i, pid;
  uint sp;
  struct proc *np;
  struct proc *curproc = myproc();

  if(fcn == 0 || stack == 0 || ((uint)stack % PGSIZE) != 0 ||
     (uint)stack + PGSIZE > curproc->sz)
    return -1;
  if((np = allocproc()) == 0)
    return -1;

  if(sharevm(curproc->pgdir) < 0){
    kfree(np->kstack);
    np->kstack = 0;
    acquire(&ptable.lock);
    np->state = UNUSED;
    release(&ptable.lock);
    return -1;
  }

  np->pgdir = curproc->pgdir;
  np->sz = curproc->sz;
  np->parent = curproc;
  np->is_thread = 1;
  *np->tf = *curproc->tf;
  np->tf->eip = (uint)fcn;
  np->tf->eax = 0;

  // cdecl entry stack: [return address][arg]. Thread functions should call exit().
  sp = (uint)stack + PGSIZE;
  sp -= sizeof(uint);
  *(uint*)sp = (uint)arg;
  sp -= sizeof(uint);
  *(uint*)sp = 0xffffffff; // returning from fcn is not supported by this ABI
  np->tf->esp = sp;

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
  pid = np->pid;

  acquire(&ptable.lock);
  np->state = RUNNABLE;
  release(&ptable.lock);
  return pid;
}

'''
    files["proc.c"] = replace_once(
        files["proc.c"], "// Exit the current process.  Does not return.\n",
        clone_code + "// Exit the current process.  Does not return.\n", "proc.c clone insertion")

    # wait(): do not reap live parent's thread children; all process address spaces
    # are released through freevmref(), which is a no-op until the last thread exits.
    wait_start = files["proc.c"].index("int\nwait(void)\n{")
    wait_end = files["proc.c"].index("//PAGEBREAK: 42", wait_start)
    wait_body = files["proc.c"][wait_start:wait_end]
    wait_body = replace_once(wait_body,
        "      if(p->parent != curproc)\n        continue;\n",
        "      if(p->parent != curproc)\n        continue;\n"
        "      // join() reaps threads while their parent is alive. Init may reap\n"
        "      // orphaned threads after their original parent exits.\n"
        "      if(p->is_thread && curproc != initproc)\n        continue;\n", "proc.c wait thread filtering")
    wait_body = replace_once(wait_body,
        "        kfree(p->kstack);\n        p->kstack = 0;\n        freevm(p->pgdir);\n        p->pid = 0;\n        p->parent = 0;\n        p->name[0] = 0;\n        p->killed = 0;\n        p->state = UNUSED;\n",
        "        kfree(p->kstack);\n        p->kstack = 0;\n        freevmref(p->pgdir);\n        p->pgdir = 0;\n        p->sz = 0;\n        p->pid = 0;\n        p->parent = 0;\n        p->name[0] = 0;\n        p->killed = 0;\n        p->is_thread = 0;\n        p->priority = 10;\n        p->wait_ticks = 0;\n        p->state = UNUSED;\n", "proc.c wait cleanup")
    files["proc.c"] = files["proc.c"][:wait_start] + wait_body + files["proc.c"][wait_end:]

    join_code = r'''// Wait for one child thread and reclaim its kernel-side resources.
// The user-owned stack page remains in the shared address space.
int
join(void)
{
  struct proc *p;
  int have_threads, pid;
  struct proc *curproc = myproc();

  acquire(&ptable.lock);
  for(;;){
    have_threads = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc || !p->is_thread)
        continue;
      have_threads = 1;
      if(p->state == ZOMBIE){
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevmref(p->pgdir);
        p->pgdir = 0;
        p->sz = 0;
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->is_thread = 0;
        p->priority = 10;
        p->wait_ticks = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }
    if(!have_threads || curproc->killed){
      release(&ptable.lock);
      return -1;
    }
    sleep(curproc, &ptable.lock);
  }
}

'''
    files["proc.c"] = replace_once(files["proc.c"], "//PAGEBREAK: 42\n",
                                     join_code + "//PAGEBREAK: 42\n", "proc.c join insertion")

    # Replace the scheduler's table-order scan with priority selection and a
    # rotating cursor for ties. A RUNNING process is preempted by xv6's timer path.
    scheduler_code = r'''void
scheduler(void)
{
  struct proc *p, *best;
  struct cpu *c = mycpu();
  static int last = NPROC - 1;
  int off, idx, bestidx;
  c->proc = 0;

  for(;;){
    sti();
    acquire(&ptable.lock);
    best = 0;
    bestidx = -1;
    // Start after the last selected slot so equal-priority processes rotate.
    for(off = 1; off <= NPROC; off++){
      idx = (last + off) % NPROC;
      p = &ptable.proc[idx];
      if(p->state != RUNNABLE)
        continue;
      if(best == 0 || p->priority < best->priority){
        best = p;
        bestidx = idx;
      }
    }
    if(best != 0){
      last = bestidx;
      c->proc = best;
      switchuvm(best);
      best->state = RUNNING;
      best->wait_ticks = 0;
      swtch(&(c->scheduler), best->context);
      switchkvm();
      c->proc = 0;
    }
    release(&ptable.lock);
  }
}

// Called once per clock tick. Aging prevents a continuously runnable low-priority
// process from waiting forever: priority numbers move upward toward 1.
void
scheduler_tick(void)
{
  struct proc *p;
  int old_priority, nlog = 0, i;
  int logpid[NPROC], oldprio[NPROC], newprio[NPROC], waited[NPROC];

  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state != RUNNABLE)
      continue;
    p->wait_ticks++;
    if(p->wait_ticks > 30){
      old_priority = p->priority;
      if(p->priority > 1){
        p->priority--;
        logpid[nlog] = p->pid;
        oldprio[nlog] = old_priority;
        newprio[nlog] = p->priority;
        waited[nlog] = p->wait_ticks;
        nlog++;
      }
      p->wait_ticks = 0;
    }
  }
  release(&ptable.lock);

  // Do console I/O only after releasing ptable.lock (avoids lock-order cycles).
  for(i = 0; i < nlog; i++)
    cprintf("aging: pid %d priority %d -> %d (wait %d ticks)\n",
            logpid[i], oldprio[i], newprio[i], waited[i]);
}

'''
    files["proc.c"] = replace_regex_once(
        files["proc.c"], r"void\s+scheduler\(void\)\s*\{.*?\n\}\n(?=// Enter scheduler\.)",
        scheduler_code, "proc.c priority scheduler", flags=re.S)

    # A wake-one primitive is used by the counting semaphore implementation.
    wake_one_code = r'''// Wake one process sleeping on chan. Used by counting semaphores.
void
wakeup_one(void *chan)
{
  struct proc *p;
  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == SLEEPING && p->chan == chan){
      p->state = RUNNABLE;
      break;
    }
  }
  release(&ptable.lock);
}

'''
    files["proc.c"] = replace_once(
        files["proc.c"], "// Kill the process with the given pid.\n",
        wake_one_code + "// Kill the process with the given pid.\n", "proc.c wakeup_one")

    files["proc.c"] += r'''

// Set/get the numeric priority of a process (1 = highest, 20 = lowest).
int
set_priority(int pid, int priority)
{
  struct proc *p;
  if(priority < 1 || priority > 20)
    return -1;
  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state != UNUSED && p->pid == pid){
      p->priority = priority;
      p->wait_ticks = 0;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

int
get_priority(int pid)
{
  struct proc *p;
  int priority = -1;
  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state != UNUSED && p->pid == pid){
      priority = p->priority;
      break;
    }
  }
  release(&ptable.lock);
  return priority;
}
'''

    # vm.c: reference counting for page directories that are shared by clone().
    files["vm.c"] = replace_once(files["vm.c"], '#include "elf.h"\n',
                                  '#include "elf.h"\n#include "spinlock.h"\n', "vm.c spinlock include")
    vmrefs = r'''// Reference counts for page directories shared by clone-created threads.
// An unregistered pgdir has one ordinary process owner. On its first share we
// record both the existing owner and the new thread (refs = 2).
static struct {
  pde_t *pgdir;
  int refs;
} vmrefs[NPROC];
static struct spinlock vmreflock;

void
vmrefinit(void)
{
  initlock(&vmreflock, "vmrefs");
}

int
sharevm(pde_t *pgdir)
{
  int i, free_slot = -1;
  acquire(&vmreflock);
  for(i = 0; i < NPROC; i++){
    if(vmrefs[i].pgdir == pgdir){
      vmrefs[i].refs++;
      release(&vmreflock);
      return 0;
    }
    if(vmrefs[i].pgdir == 0 && free_slot < 0)
      free_slot = i;
  }
  if(free_slot < 0){
    release(&vmreflock);
    return -1;
  }
  vmrefs[free_slot].pgdir = pgdir;
  vmrefs[free_slot].refs = 2;
  release(&vmreflock);
  return 0;
}

void
freevmref(pde_t *pgdir)
{
  int i, should_free = 1;
  if(pgdir == 0)
    panic("freevmref: no pgdir");
  acquire(&vmreflock);
  for(i = 0; i < NPROC; i++){
    if(vmrefs[i].pgdir == pgdir){
      vmrefs[i].refs--;
      if(vmrefs[i].refs > 0)
        should_free = 0;
      else {
        vmrefs[i].pgdir = 0;
        vmrefs[i].refs = 0;
      }
      break;
    }
  }
  release(&vmreflock);
  if(should_free)
    freevm(pgdir);
}

'''
    files["vm.c"] = replace_once(files["vm.c"], "pde_t *kpgdir;  // for use in scheduler()\n",
                                  "pde_t *kpgdir;  // for use in scheduler()\n\n" + vmrefs,
                                  "vm.c refcount insertion")

    # Age only after releasing tickslock; scheduler_tick takes ptable.lock.
    files["trap.c"] = replace_once(
        files["trap.c"], "      release(&tickslock);\n    }\n    lapiceoi();\n",
        "      release(&tickslock);\n"
        "      scheduler_tick();\n"
        "    }\n"
        "    lapiceoi();\n", "trap.c timer aging hook")

    # Write modified existing files only after every expected upstream marker passed.
    for name, content in files.items():
        (root / name).write_text(content)

    # New kernel and user files are copied into the xv6 root for Makefile discovery.
    shutil.copy2(bundle / "kernel" / "sem.c", root / "sem.c")
    for name in ("threadtest.c", "synctest.c", "deadlock.c", "priotest.c"):
        shutil.copy2(bundle / "user" / name, root / name)

    print("Assignment 7 files installed into:", root)
    print("Next: make clean && make; then run make CPUS=2 qemu-nox for thread tests.")
    print("For the priority test, use make CPUS=1 qemu-nox for clearer aging behavior.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("Assignment 7 patch failed before writing existing files:", exc, file=sys.stderr)
        raise SystemExit(1)
