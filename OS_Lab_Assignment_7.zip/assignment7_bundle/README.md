# OS Lab Assignment 7 - xv6-public (x86)

This bundle provides the source files for Q1-Q4 and an installer for the kernel changes. The consolidated report is intentionally omitted.

## Files supplied

- `user/threadtest.c` - Q1 shared-address-space thread/race test.
- `user/synctest.c` - Q2 semaphore-protected counter and bounded-buffer producer/consumer test.
- `user/deadlock.c` - Q3 deadlock detection, Banker's safety/request check, and a real pipe-blocking demonstration.
- `user/priotest.c` - Q4 priority scheduling and aging test.
- `kernel/sem.c` - Q2 kernel counting semaphore implementation.
- `apply_assignment7.py` - integrates kernel modifications into an unmodified `xv6-public` x86 source tree and copies the user programs into it.

## Target version and installation

This targets the classic MIT `xv6-public` **x86** source tree, whose kernel has `proc.c`, `vm.c`, `trap.c`, and `usys.S`. It is not a patch for `xv6-riscv`.

1. Extract the official `xv6-public` source tree.
2. Keep a backup or commit your source tree in version control.
3. From this bundle, run:

   ```sh
   python3 apply_assignment7.py /path/to/xv6-public
   ```

4. In the xv6 source directory, build from clean sources:

   ```sh
   make clean
   make
   ```

The installer edits `proc.h`, `proc.c`, `vm.c`, `defs.h`, `sysproc.c`, `syscall.c`, `syscall.h`, `user.h`, `usys.S`, `trap.c`, and `Makefile`. It adds `sem.c` and the four user programs. It checks the upstream source markers before writing modified existing files; if it finds a mismatch, it stops rather than silently applying a partial edit.

## Running the tests

Start xv6 with two virtual CPUs to make the unsynchronized counter race easier to observe:

```sh
make CPUS=2 qemu-nox
```

At the xv6 shell, run each command separately:

```text
threadtest
synctest
deadlock
```

For the priority scheduler test, shut down and restart xv6 with a single CPU so the priority/aging behavior is easier to interpret:

```sh
make CPUS=1 qemu-nox
```

Then run:

```text
priotest
```

## Design notes and assumptions

- The `clone(fcn, arg, stack)` API takes `stack` as the **page-aligned base address** of a 4096-byte user stack page. The kernel places the argument and a synthetic return address on it. Thread entry functions in the tests call `exit()` instead of returning.
- `join()` returns the PID of one reaped thread, or `-1` when the caller has no joinable thread children. It releases that thread's kernel stack/process-table slot and decrements the shared page-directory reference count. The user-allocated stack page remains in the caller's shared address space; the caller owns user-stack allocation/reclamation.
- `fork()` still creates a copied address space. Threads receive duplicated file and current-directory references so that a thread's `exit()` does not close another thread's references.
- Semaphores use ten fixed kernel slots. IDs are 0-9. Initialize a semaphore before use; reinitialize only when no thread is waiting on it. `wakeup_one()` is added because xv6's ordinary `wakeup()` awakens every process on a channel.
- `deadlock.c` runs the matrix algorithm in user space as requested. xv6 does not expose a general kernel resource-allocation graph, so the pipe example creates two actual blocked children, correlates them with the modeled circular wait, and kills/reaps them so the test returns to the shell.
- The priority scheduler picks the smallest priority number and rotates its scan cursor to break ties. Runnable wait counters are aged by the timer interrupt path after releasing `tickslock`. Kernel console lines beginning with `aging:` show priority changes.

## Output / screenshot requirement

The source bundle does not include made-up terminal screenshots. Capture real xv6/QEMU output after building and running each program on your machine. For Q1, the unsynchronized result is timing-dependent: it can be below 300000, but it may occasionally equal 300000. For Q2, the protected counter should be exactly 300000 and the producer-consumer log should show ten inserted and ten removed items.
