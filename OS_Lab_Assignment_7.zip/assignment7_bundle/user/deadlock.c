// Q3: User-space deadlock detection and Banker's safety/request checks.
// The resource-matrix simulation is user-space. The final section also creates
// two real xv6 children blocked on opposite pipes, then terminates them safely.
#include "types.h"
#include "user.h"

#define MAXP 5
#define MAXR 3

static void
print_vector(const char *label, int values[MAXR], int m)
{
  int r;
  printf(1, "%s [", label);
  for(r = 0; r < m; r++)
    printf(1, "%s%d", r ? ", " : "", values[r]);
  printf(1, "]\n");
}

static void
print_matrix(const char *label, int matrix[MAXP][MAXR], int n, int m)
{
  int i, r;
  printf(1, "%s:\n", label);
  for(i = 0; i < n; i++) {
    printf(1, "  P%d [", i);
    for(r = 0; r < m; r++)
      printf(1, "%s%d", r ? ", " : "", matrix[i][r]);
    printf(1, "]\n");
  }
}

static void
print_detection_state(int n, int m, int allocation[MAXP][MAXR],
                      int request[MAXP][MAXR], int available[MAXR])
{
  print_vector("Available", available, m);
  print_matrix("Allocation", allocation, n, m);
  print_matrix("Request", request, n, m);
}

// Returns the number of deadlocked processes. Their zero-based indices are
// written to deadlocked[]. This is the standard deadlock-detection algorithm.
static int
detect_deadlock(int n, int m, int allocation[MAXP][MAXR],
                int request[MAXP][MAXR], int available[MAXR],
                int deadlocked[MAXP])
{
  int work[MAXR];
  int finish[MAXP];
  int i, r, progress, count;

  for(r = 0; r < m; r++)
    work[r] = available[r];
  for(i = 0; i < n; i++) {
    int has_allocation = 0;
    for(r = 0; r < m; r++)
      if(allocation[i][r] != 0)
        has_allocation = 1;
    finish[i] = !has_allocation;
  }

  printf(1, "\n-- Deadlock-detection trace --\n");
  print_detection_state(n, m, allocation, request, work);
  do {
    progress = 0;
    for(i = 0; i < n; i++) {
      int can_finish = 1;
      if(finish[i])
        continue;
      for(r = 0; r < m; r++)
        if(request[i][r] > work[r])
          can_finish = 0;
      if(!can_finish)
        continue;
      printf(1, "P%d can finish; release its allocation.\n", i);
      for(r = 0; r < m; r++)
        work[r] += allocation[i][r];
      finish[i] = 1;
      progress = 1;
      print_vector("  Work/Available", work, m);
    }
  } while(progress);

  count = 0;
  for(i = 0; i < n; i++) {
    if(!finish[i]) {
      deadlocked[count++] = i;
      printf(1, "P%d remains unfinished: deadlocked candidate.\n", i);
    }
  }
  if(count == 0)
    printf(1, "No deadlock detected.\n");
  return count;
}

static int
need_is_available(int need[MAXP][MAXR], int process, int work[MAXR], int m)
{
  int r;
  for(r = 0; r < m; r++)
    if(need[process][r] > work[r])
      return 0;
  return 1;
}

static void
print_banker_state(int n, int m, int allocation[MAXP][MAXR],
                   int maximum[MAXP][MAXR], int available[MAXR],
                   int need[MAXP][MAXR])
{
  int i, r;
  print_vector("Available", available, m);
  print_matrix("Allocation", allocation, n, m);
  for(i = 0; i < n; i++)
    for(r = 0; r < m; r++)
      need[i][r] = maximum[i][r] - allocation[i][r];
  print_matrix("Need", need, n, m);
}

// Returns 1 if the supplied state is safe, otherwise 0. A safe sequence is
// printed as processes are found able to complete.
static int
is_safe_state(int n, int m, int allocation[MAXP][MAXR],
              int maximum[MAXP][MAXR], int available[MAXR])
{
  int need[MAXP][MAXR];
  int work[MAXR];
  int finish[MAXP];
  int sequence[MAXP];
  int i, r, completed, progress;

  print_banker_state(n, m, allocation, maximum, available, need);
  for(r = 0; r < m; r++)
    work[r] = available[r];
  for(i = 0; i < n; i++)
    finish[i] = 0;
  completed = 0;

  do {
    progress = 0;
    for(i = 0; i < n; i++) {
      if(finish[i] || !need_is_available(need, i, work, m))
        continue;
      finish[i] = 1;
      sequence[completed++] = i;
      for(r = 0; r < m; r++)
        work[r] += allocation[i][r];
      printf(1, "P%d can finish; Work becomes [%d, %d, %d]\n",
             i, work[0], work[1], work[2]);
      progress = 1;
    }
  } while(progress);

  if(completed == n) {
    printf(1, "SAFE state. Sequence: ");
    for(i = 0; i < completed; i++)
      printf(1, "%sP%d", i ? " -> " : "", sequence[i]);
    printf(1, "\n");
    return 1;
  }
  printf(1, "UNSAFE state. Unfinished processes:");
  for(i = 0; i < n; i++)
    if(!finish[i])
      printf(1, " P%d", i);
  printf(1, "\n");
  return 0;
}

// Banker request attempt: grant only if the request satisfies both current
// availability and Need and leaves the system in a safe state.
static int
banker_request(int n, int m, int allocation[MAXP][MAXR],
               int maximum[MAXP][MAXR], int available[MAXR],
               int process, int request[MAXR])
{
  int trial_allocation[MAXP][MAXR];
  int trial_available[MAXR];
  int i, r;

  for(r = 0; r < m; r++) {
    int need = maximum[process][r] - allocation[process][r];
    if(request[r] > need || request[r] > available[r]) {
      printf(1, "Request from P%d rejected: exceeds Need or Available.\n", process);
      return 0;
    }
  }
  for(i = 0; i < n; i++)
    for(r = 0; r < m; r++)
      trial_allocation[i][r] = allocation[i][r];
  for(r = 0; r < m; r++) {
    trial_available[r] = available[r] - request[r];
    trial_allocation[process][r] += request[r];
  }

  printf(1, "\nTesting hypothetical request from P%d: [%d, %d, %d]\n",
         process, request[0], request[1], request[2]);
  if(!is_safe_state(n, m, trial_allocation, maximum, trial_available)) {
    printf(1, "Request DENIED: it would leave the system unsafe.\n");
    return 0;
  }
  for(i = 0; i < n; i++)
    for(r = 0; r < m; r++)
      allocation[i][r] = trial_allocation[i][r];
  for(r = 0; r < m; r++)
    available[r] = trial_available[r];
  printf(1, "Request GRANTED: resulting state is safe.\n");
  return 1;
}

static void
run_pipe_deadlock_demo(void)
{
  int p1[2], p2[2];
  int pid_a, pid_b;
  char byte;

  printf(1, "\n-- Real pipe-based circular-wait demonstration --\n");
  if(pipe(p1) < 0 || pipe(p2) < 0) {
    printf(2, "pipe creation failed; skipping process demonstration\n");
    return;
  }

  pid_a = fork();
  if(pid_a == 0) {
    close(p1[0]);             // A holds Pipe1's write end.
    close(p2[1]);             // A reads Pipe2 while B keeps its writer open.
    printf(1, "Process A (pid %d): waiting to read Pipe2\n", getpid());
    read(p2[0], &byte, 1);    // Blocks: B holds Pipe2 write end, no data written.
    exit();
  }
  if(pid_a < 0) {
    printf(2, "fork for process A failed\n");
    close(p1[0]); close(p1[1]); close(p2[0]); close(p2[1]);
    return;
  }

  pid_b = fork();
  if(pid_b == 0) {
    close(p2[0]);             // B holds Pipe2's write end.
    close(p1[1]);             // B reads Pipe1 while A keeps its writer open.
    printf(1, "Process B (pid %d): waiting to read Pipe1\n", getpid());
    read(p1[0], &byte, 1);    // Blocks: A holds Pipe1 write end, no data written.
    exit();
  }
  close(p1[0]); close(p1[1]); close(p2[0]); close(p2[1]);
  if(pid_b < 0) {
    printf(2, "fork for process B failed\n");
    kill(pid_a);
    wait();
    return;
  }

  sleep(20); // Give both children time to block in read().
  printf(1, "Pipe model: A waits on Pipe2 while B waits on Pipe1; circular wait exists.\n");
  printf(1, "The static detector above reports both modeled processes as deadlocked.\n");
  // xv6 has no general kernel resource-graph introspection. Terminate the two
  // intentionally blocked demonstration processes so the test can finish.
  kill(pid_a);
  kill(pid_b);
  wait();
  wait();
  printf(1, "Blocked pipe children cleaned up.\n");
}

int
main(void)
{
  int dead[MAXP];
  int count, i;

  // Case 1: P0 holds R0 and requests R1; P1 holds R1 and requests R0.
  {
    int allocation[MAXP][MAXR] = {{1,0,0}, {0,1,0}};
    int request[MAXP][MAXR] = {{0,1,0}, {1,0,0}};
    int available[MAXR] = {0,0,0};
    printf(1, "\n========== Matrix 1: deadlocked ==========" "\n");
    count = detect_deadlock(2, 2, allocation, request, available, dead);
    printf(1, "Deadlocked process count = %d; processes:", count);
    for(i = 0; i < count; i++) printf(1, " P%d", dead[i]);
    printf(1, "\n");
  }

  // Case 2: P1 needs no more resources, completes, and releases R1 for P0.
  {
    int allocation[MAXP][MAXR] = {{1,0,0}, {0,1,0}};
    int request[MAXP][MAXR] = {{0,1,0}, {0,0,0}};
    int available[MAXR] = {0,0,0};
    printf(1, "\n========== Matrix 2: no deadlock ==========" "\n");
    count = detect_deadlock(2, 2, allocation, request, available, dead);
    printf(1, "Deadlocked process count = %d\n", count);
  }

  // Classic five-process/three-resource Banker's example. Initial state is safe;
  // the hypothetical P4 request [3,3,0] is available and within Need but unsafe.
  {
    int allocation[MAXP][MAXR] = {
      {0,1,0}, {2,0,0}, {3,0,2}, {2,1,1}, {0,0,2}
    };
    int maximum[MAXP][MAXR] = {
      {7,5,3}, {3,2,2}, {9,0,2}, {2,2,2}, {4,3,3}
    };
    int available[MAXR] = {3,3,2};
    int request[MAXR] = {3,3,0};
    printf(1, "\n========== Matrix 3: Banker's safety test ==========" "\n");
    if(is_safe_state(5, 3, allocation, maximum, available))
      printf(1, "Initial Banker's state is safe.\n");
    banker_request(5, 3, allocation, maximum, available, 4, request);
  }

  // Resource model: Pipe1 and Pipe2 are the two resource types. Process A
  // holds Pipe1 and requests Pipe2; process B holds Pipe2 and requests Pipe1.
  run_pipe_deadlock_demo();
  exit();
}
