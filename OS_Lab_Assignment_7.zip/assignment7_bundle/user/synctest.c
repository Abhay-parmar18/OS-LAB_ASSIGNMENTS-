// Q2: Semaphore-protected shared counter plus bounded-buffer producer/consumer.
#include "types.h"
#include "user.h"

#define STACK_SIZE 4096
#define THREADS 3
#define ITERATIONS 100000
#define BUFFER_SIZE 5
#define ITEMS 10

volatile int counter = 0;
int buffer[BUFFER_SIZE];
int in_index = 0;
int out_index = 0;

static void
increment_locked(void *arg)
{
  int i;
  (void)arg;
  for(i = 0; i < ITERATIONS; i++) {
    sem_wait(0);       // mutex semaphore
    counter++;
    sem_signal(0);
  }
  exit();
}

static void
producer(void *arg)
{
  int i;
  (void)arg;
  for(i = 1; i <= ITEMS; i++) {
    sem_wait(1);       // empty slots
    sem_wait(0);       // mutex
    buffer[in_index] = i;
    in_index = (in_index + 1) % BUFFER_SIZE;
    printf(1, "producer: inserted %d\n", i);
    sem_signal(0);
    sem_signal(2);     // full slots
  }
  exit();
}

static void
consumer(void *arg)
{
  int i, item;
  (void)arg;
  for(i = 0; i < ITEMS; i++) {
    sem_wait(2);       // full slots
    sem_wait(0);       // mutex
    item = buffer[out_index];
    out_index = (out_index + 1) % BUFFER_SIZE;
    printf(1, "consumer: removed %d\n", item);
    sem_signal(0);
    sem_signal(1);     // empty slots
  }
  exit();
}

static char *
new_stack(void)
{
  char *stack = sbrk(STACK_SIZE);
  if(stack == (char*)-1)
    return 0;
  if(((uint)stack % STACK_SIZE) != 0)
    return 0;
  return stack;
}

int
main(void)
{
  int i;
  int tid;
  char *stacks[THREADS];
  char *pstack, *cstack;

  for(i = 0; i < THREADS; i++) {
    stacks[i] = new_stack();
    if(stacks[i] == 0) {
      printf(2, "synctest: stack allocation failed\n");
      exit();
    }
  }

  if(sem_init(0, 1) < 0) {
    printf(2, "synctest: sem_init(mutex) failed\n");
    exit();
  }
  counter = 0;
  for(i = 0; i < THREADS; i++) {
    tid = clone(increment_locked, (void*)0, stacks[i]);
    if(tid < 0) {
      printf(2, "synctest: clone failed\n");
      exit();
    }
  }
  for(i = 0; i < THREADS; i++)
    if(join() < 0) {
      printf(2, "synctest: join failed after counter test\n");
      exit();
    }
  printf(1, "Q2 synchronized counter = %d (expected %d)\n",
         counter, THREADS * ITERATIONS);

  // Reinitialise the mutex only after all counter threads have joined.
  sem_init(0, 1);
  sem_init(1, BUFFER_SIZE);
  sem_init(2, 0);
  in_index = 0;
  out_index = 0;
  pstack = new_stack();
  cstack = new_stack();
  if(pstack == 0 || cstack == 0) {
    printf(2, "synctest: producer/consumer stack allocation failed\n");
    exit();
  }

  if(clone(producer, (void*)0, pstack) < 0 ||
     clone(consumer, (void*)0, cstack) < 0) {
    printf(2, "synctest: producer/consumer clone failed\n");
    exit();
  }
  if(join() < 0 || join() < 0) {
    printf(2, "synctest: producer/consumer join failed\n");
    exit();
  }
  printf(1, "Q2 producer-consumer completed: %d items, buffer capacity %d\n",
         ITEMS, BUFFER_SIZE);
  exit();
}
