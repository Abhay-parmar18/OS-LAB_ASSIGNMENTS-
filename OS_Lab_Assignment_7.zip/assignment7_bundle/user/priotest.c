// Q4: Priority scheduler and aging test.
// Suggested: run with `make CPUS=1 qemu-nox` for deterministic scheduler behavior.
#include "types.h"
#include "user.h"

#define CHILDREN 4
#define START_SEM 4

int requested_priorities[CHILDREN] = {1, 5, 10, 20};

static void
busy_work(uint loops)
{
  uint i;
  volatile uint accumulator = 0;
  for(i = 0; i < loops; i++)
    accumulator += (i & 1);
  // Keep the result observable so the compiler cannot remove the loop.
  if(accumulator == 0xffffffffU)
    printf(1, "unexpected accumulator value\n");
}

int
main(void)
{
  int i, pid;

  if(sem_init(START_SEM, 0) < 0) {
    printf(2, "priotest: semaphore initialization failed\n");
    exit();
  }

  for(i = 0; i < CHILDREN; i++) {
    pid = fork();
    if(pid == 0) {
      // Wait until the parent has installed every child priority.
      sem_wait(START_SEM);
      if(requested_priorities[i] == 1)
        busy_work(200000000U);   // long-running high-priority process
      else
        busy_work(12000000U);
      printf(1, "completed pid=%d requested_priority=%d final_priority=%d\n",
             getpid(), requested_priorities[i], get_priority(getpid()));
      exit();
    }
    if(pid < 0) {
      printf(2, "priotest: fork failed at child %d\n", i);
      exit();
    }
    if(set_priority(pid, requested_priorities[i]) < 0) {
      printf(2, "priotest: set_priority failed for pid %d\n", pid);
      exit();
    }
    printf(1, "created pid=%d requested_priority=%d actual_priority=%d\n",
           pid, requested_priorities[i], get_priority(pid));
  }

  // Release all four blocked children. The priority-1 process remains runnable
  // for longer, allowing the others' wait-tick aging counters to advance.
  for(i = 0; i < CHILDREN; i++)
    sem_signal(START_SEM);

  for(i = 0; i < CHILDREN; i++)
    wait();

  printf(1, "priotest complete. Look for kernel 'aging:' messages showing a\n");
  printf(1, "decreasing priority number for waiting RUNNABLE processes.\n");
  exit();
}
