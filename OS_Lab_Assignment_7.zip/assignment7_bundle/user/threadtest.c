// Q1: User-level interface to the xv6 kernel-supported threads.
// Run with CPUS=2 to make the unsynchronised increment race easier to observe.
#include "types.h"
#include "user.h"

#define STACK_SIZE 4096
#define THREADS 3
#define ITERATIONS 100000

volatile int counter = 0;

static void
increment(void *arg)
{
  int i;
  (void)arg;
  for(i = 0; i < ITERATIONS; i++)
    counter++;
  // clone() starts this function directly. A thread function must exit rather
  // than return, because clone's synthetic return address is deliberately invalid.
  exit();
}

int
main(void)
{
  int i;
  int tids[THREADS];
  char *stacks[THREADS];

  for(i = 0; i < THREADS; i++) {
    stacks[i] = sbrk(STACK_SIZE);
    if(stacks[i] == (char*)-1) {
      printf(2, "threadtest: unable to allocate stack %d\n", i);
      exit();
    }
    if(((uint)stacks[i] % STACK_SIZE) != 0) {
      printf(2, "threadtest: stack %d is not page aligned\n", i);
      exit();
    }
  }

  for(i = 0; i < THREADS; i++) {
    tids[i] = clone(increment, (void*)0, stacks[i]);
    if(tids[i] < 0) {
      printf(2, "threadtest: clone failed for thread %d\n", i);
      exit();
    }
    printf(1, "created thread pid=%d\n", tids[i]);
  }

  for(i = 0; i < THREADS; i++) {
    int tid = join();
    if(tid < 0) {
      printf(2, "threadtest: join failed\n");
      exit();
    }
    printf(1, "joined thread pid=%d\n", tid);
  }

  printf(1, "Q1 final shared counter = %d (expected without races: %d)\n",
         counter, THREADS * ITERATIONS);
  exit();
}
