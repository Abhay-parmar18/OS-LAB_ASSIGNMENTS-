# Assignment 7 file map (report excluded)

| Question | Required source | What it demonstrates |
|---|---|---|
| Q1 - Threads | `user/threadtest.c` | Creates three threads sharing a global counter and joins each one. |
| Q2 - Semaphores | `user/synctest.c`, `kernel/sem.c` | Protects the counter with a mutex semaphore and runs a size-5 bounded buffer producer-consumer test. |
| Q3 - Deadlock | `user/deadlock.c` | Runs deadlock detection, Banker's safety/request validation, and a pipe-based circular-wait demo. |
| Q4 - Scheduling | `user/priotest.c` | Sets four child priorities, prints completion order, and shows aging logs from the kernel. |
| Shared kernel plumbing | `apply_assignment7.py` | Adds syscall declarations/dispatch/stubs; changes `proc.c`, `proc.h`, `vm.c`, `trap.c`, `defs.h`, and `Makefile`. |

No report or terminal screenshots are included. Screenshots need to be captured from real output after running the built kernel in QEMU.
