#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAX_PROC 5

int adj[MAX_PROC][MAX_PROC];
int visited[MAX_PROC];
int rec_stack[MAX_PROC];
int path[MAX_PROC];
int path_len = 0;

void build_wait_for_graph(int alloc[MAX_PROC][MAX_PROC], int req[MAX_PROC][MAX_PROC], int n) {
    int i, j, r;
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            adj[i][j] = 0;

   
    for (i = 0; i < n; i++) {
        for (r = 0; r < MAX_PROC; r++) {
            if (req[i][r]) { 
                for (j = 0; j < n; j++) {
                    if (alloc[j][r] && i != j) {
                        adj[i][j] = 1;
                    }
                }
            }
        }
    }
}

int dfs(int u, int n) {
    visited[u] = 1;
    rec_stack[u] = 1;
    path[path_len++] = u;

    int v;
    for (v = 0; v < n; v++) {
        if (adj[u][v]) {
            if (!visited[v] && dfs(v, n)) {
                return 1;
            } else if (rec_stack[v]) {
                path[path_len++] = v;
                return 1;
            }
        }
    }

    rec_stack[u] = 0;
    path_len--;
    return 0;
}

void detect_deadlock(int alloc[MAX_PROC][MAX_PROC], int req[MAX_PROC][MAX_PROC], int n, const char* label) {
    printf("\n--- %s ---\n", label);
    build_wait_for_graph(alloc, req, n);

    int i;
    for (i = 0; i < n; i++) {
        visited[i] = 0;
        rec_stack[i] = 0;
    }

    int deadlock_found = 0;
    for (i = 0; i < n; i++) {
        path_len = 0;
        if (!visited[i] && dfs(i, n)) {
            deadlock_found = 1;
            printf("Deadlock Detected! Cycle found: ");
            int start_idx = 0;
           
            int target = path[path_len - 1];
            int k;
            for (k = 0; k < path_len - 1; k++) {
                if (path[k] == target) {
                    start_idx = k;
                    break;
                }
            }
            for (k = start_idx; k < path_len; k++) {
                printf("P%d%s", path[k], (k == path_len - 1) ? "" : " -> ");
            }
            printf("\n");
            break;
        }
    }

    if (!deadlock_found) {
        printf("No deadlock detected. Graph is acyclic.\n");
    }
}

int main(int argc, char *argv[]) {
    printf("=== Question 2: Deadlock Detection (RAG / Wait-For Graph) ===\n");

    
    int alloc1[MAX_PROC][MAX_PROC] = {
        {1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, 0}, {0, 0, 0}
    };
    int req1[MAX_PROC][MAX_PROC] = {
        {0, 1, 0}, {0, 0, 1}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}
    };
    detect_deadlock(alloc1, req1, 3, "Scenario 1: Acyclic Graph (No Deadlock)");

    
    int alloc2[MAX_PROC][MAX_PROC] = {
        {1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, 0}, {0, 0, 0}
    };
    int req2[MAX_PROC][MAX_PROC] = {
        {0, 1, 0}, {0, 0, 1}, {1, 0, 0}, {0, 0, 0}, {0, 0, 0}
    };
    detect_deadlock(alloc2, req2, 3, "Scenario 2: Circular Wait among 3 Processes");

    exit(0);
}