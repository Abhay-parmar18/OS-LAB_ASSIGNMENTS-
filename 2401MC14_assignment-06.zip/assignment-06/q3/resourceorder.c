#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"



void run_deadlocking_scenario() {
    printf("\n[Scenario A] Running Deadlocking Configuration (Inconsistent Order)...\n");
    printf("Process A locks 1 then 2. Process B locks 2 then 1.\n");
    
    int pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        exit(1);
    } else if (pid == 0) {
        
        printf("Process B: Acquiring Lock 2...\n");
        sleep(10); 
        printf("Process B: Trying to acquire Lock 1 (Will hang if Process A holds it)...\n");
       
        exit(0);
    } else {
        
        printf("Process A: Acquiring Lock 1...\n");
        sleep(5);
        printf("Process A: Trying to acquire Lock 2 (Will hang if Process B holds it)...\n");
        
       
        wait(0);
        wait(0);
    }
}

void run_fixed_scenario() {
    printf("\n[Scenario B] Running Fixed Configuration (Hierarchical Resource Ordering)...\n");
    printf("Both Process A and Process B strictly acquire Lock 1 BEFORE Lock 2.\n");

    int pid = fork();
    if (pid == 0) {
        
        printf("Process B: Acquiring Lock 1 (lower order first)...\n");
        sleep(2);
        printf("Process B: Acquiring Lock 2...\n");
        printf("Process B: Completed work and released all locks safely.\n");
        exit(0);
    } else {
       
        printf("Process A: Acquiring Lock 1 (lower order first)...\n");
        sleep(1);
        printf("Process A: Acquiring Lock 2...\n");
        printf("Process A: Completed work and released all locks safely.\n");
        
        wait(0);
    }
}

int main(int argc, char *argv[]) {
    printf("=== Question 3: Deadlock Prevention via Resource Ordering ===\n");
    
    run_deadlocking_scenario();
    run_fixed_scenario();

    printf("\nExplanation: Resource ordering eliminates circular wait because every process acquires resources in a strict global sequence. If Process A holds resource 2, it cannot be waiting for resource 1 if resource 1 must be acquired first, breaking the cycle condition required for deadlock.\n");
    exit(0);
}