#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define P_COUNT 5
#define R_COUNT 3

int allocation[P_COUNT][R_COUNT] = {
    {0, 1, 0},
    {2, 0, 0},
    {3, 0, 2},
    {2, 1, 1},
    {0, 0, 2}
};

int max[P_COUNT][R_COUNT] = {
    {7, 5, 3},
    {3, 2, 2},
    {9, 0, 2},
    {2, 2, 2},
    {4, 3, 3}
};

int available[R_COUNT] = {3, 3, 2};

void print_matrices() {
    int i, j;
    printf("\n--- Current System State ---\n");
    printf("PID\tAllocation\tMax\t\tNeed\n");
    for (i = 0; i < P_COUNT; i++) {
        printf("P%d\t", i);
        for (j = 0; j < R_COUNT; j++) printf("%d ", allocation[i][j]);
        printf("\t\t");
        for (j = 0; j < R_COUNT; j++) printf("%d ", max[i][j]);
        printf("\t\t");
        for (j = 0; j < R_COUNT; j++) printf("%d ", max[i][j] - allocation[i][j]);
        printf("\n");
    }
    printf("Available: [%d, %d, %d]\n\n", available[0], available[1], available[2]);
}

int run_safety_algorithm(int *safe_seq) {
    int work[R_COUNT];
    int finish[P_COUNT];
    int i, j, k;

    for (i = 0; i < R_COUNT; i++) work[i] = available[i];
    for (i = 0; i < P_COUNT; i++) finish[i] = 0;

    int count = 0;
    while (count < P_COUNT) {
        int found = 0;
        for (i = 0; i < P_COUNT; i++) {
            if (!finish[i]) {
                int can_proceed = 1;
                for (j = 0; j < R_COUNT; j++) {
                    if ((max[i][j] - allocation[i][j]) > work[j]) {
                        can_proceed = 0;
                        break;
                    }
                }
                if (can_proceed) {
                    for (k = 0; k < R_COUNT; k++) work[k] += allocation[i][k];
                    safe_seq[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }
        if (!found) return 0; 
    }
    return 1; 
}

void request_resources(int p_id, int req[]) {
    int j;
    printf("Process P%d requests resources [%d, %d, %d]\n", p_id, req[0], req[1], req[2]);

    for (j = 0; j < R_COUNT; j++) {
        if (req[j] > (max[p_id][j] - allocation[p_id][j])) {
            printf("Error: Process exceeded its maximum declared need.\n");
            return;
        }
        if (req[j] > available[j]) {
            printf("Request denied: Not enough resources currently available. Process must wait.\n");
            return;
        }
    }

    
    for (j = 0; j < R_COUNT; j++) {
        available[j] -= req[j];
        allocation[p_id][j] += req[j];
    }

    int safe_seq[P_COUNT];
    if (run_safety_algorithm(safe_seq)) {
        printf("Request GRANTED safely. Safe sequence: ");
        for (j = 0; j < P_COUNT; j++) printf("P%d ", safe_seq[j]);
        printf("\n");
    } else {
        
        for (j = 0; j < R_COUNT; j++) {
            available[j] += req[j];
            allocation[p_id][j] -= req[j];
        }
        printf("Request denied: Would lead to unsafe state (rollback performed).\n");
    }
}

int main(int argc, char *argv[]) {
    printf("=== Question 1: Banker's Algorithm Simulation ===\n");
    print_matrices();

    int safe_seq[P_COUNT];
    if (run_safety_algorithm(safe_seq)) {
        printf("Initial state is SAFE. Safe sequence: ");
        int i;
        for (i = 0; i < P_COUNT; i++) printf("P%d ", safe_seq[i]);
        printf("\n\n");
    } else {
        printf("Initial state is UNSAFE.\n");
    }

    
    printf("--- Scenario 1: Safe Request ---\n");
    int req1[3] = {1, 0, 2};
    request_resources(1, req1);

   
    printf("\n--- Scenario 2: Unsafe Request ---\n");
    int req2[3] = {0, 2, 0};
    request_resources(0, req2);

    exit(0);
}