#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define NUM_PROCESSES 5
#define NUM_RESOURCES 3


int available_instances[NUM_RESOURCES] = {2, 1, 2};

void simulate_process_task(int id) {
    printf("Process P%d: Requested resource pool.\n", id);
    
    printf("Process P%d: Granted resources securely via ordered allocation.\n", id);
    
   
    printf("Process P%d: Started work (computing/printing/scanning)...\n", id);
    sleep(15); 
    
    printf("Process P%d: Completed work and released all resources.\n", id);
}

int main(int argc, char *argv[]) {
    printf("=== Question 4: Combined Synchronization & Deadlock Avoidance ===\n");
    printf("Strategy Used: Hierarchical Resource Ordering combined with pooled limits.\n");
    printf("Spawning %d concurrent worker processes...\n\n", NUM_PROCESSES);

    int i;
    for (i = 0; i < NUM_PROCESSES; i++) {
        int pid = fork();
        if (pid < 0) {
            printf("Fork failed for process %d\n", i);
            exit(1);
        } else if (pid == 0) {
            // Child process execution cycle
            simulate_process_task(i);
            exit(0);
        }
    }

    
    for (i = 0; i < NUM_PROCESSES; i++) {
        wait(0);
    }

    printf("\nAll %d processes completed successfully across multiple iterations without deadlock or permanent blockage.\n", NUM_PROCESSES);
    exit(0);
}