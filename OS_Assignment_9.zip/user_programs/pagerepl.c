#include "types.h"
#include "stat.h"
#include "user.h"

#define MAXREF 64
#define MAXFRAMES 16

static int refs[20] = {7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};

static int
findpage(int f[], int n, int x)
{
  int i;
  for(i=0;i<n;i++) if(f[i]==x) return i;
  return -1;
}

static int
fifo(int n, int verbose)
{
  int f[MAXFRAMES], i, j, filled=0, next=0, faults=0, hit;
  for(i=0;i<MAXFRAMES;i++) f[i]=-1;
  if(verbose) printf(1,"\\nFIFO (%d frames)\\n",n);
  for(i=0;i<20;i++){
    hit=findpage(f,n,refs[i]);
    if(hit<0){
      faults++;
      if(filled<n) f[filled++]=refs[i];
      else { f[next]=refs[i]; next=(next+1)%n; }
    }
    if(verbose){
      printf(1,"%d: %s [",refs[i],hit<0?"fault":"hit");
      for(j=0;j<n;j++) printf(1,"%s%d",j?" ":"",f[j]);
      printf(1,"]\\n");
    }
  }
  return faults;
}

static int
lru(int n, int verbose)
{
  int f[MAXFRAMES], last[MAXFRAMES], i,j,filled=0,faults=0,hit,victim,oldest;
  for(i=0;i<MAXFRAMES;i++){f[i]=-1;last[i]=-1;}
  if(verbose) printf(1,"\\nLRU (%d frames)\\n",n);
  for(i=0;i<20;i++){
    hit=findpage(f,n,refs[i]);
    if(hit>=0) last[hit]=i;
    else {
      faults++;
      if(filled<n) victim=filled++;
      else {
        victim=0; oldest=last[0];
        for(j=1;j<n;j++) if(last[j]<oldest){oldest=last[j];victim=j;}
      }
      f[victim]=refs[i]; last[victim]=i;
    }
    if(verbose){
      printf(1,"%d: %s [",refs[i],hit<0?"fault":"hit");
      for(j=0;j<n;j++) printf(1,"%s%d",j?" ":"",f[j]);
      printf(1,"]\\n");
    }
  }
  return faults;
}

int
main(void)
{
  int n, ff, lf;
  printf(1,"Q3 reference string: 7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1\\n");
  fifo(3,1); lru(3,1);
  printf(1,"\\nFrames | FIFO faults | FIFO hit ratio | LRU faults | LRU hit ratio\\n");
  for(n=3;n<=5;n++){
    ff=fifo(n,0); lf=lru(n,0);
    printf(1,"%d | %d | %d/20 | %d | %d/20\\n",n,ff,20-ff,lf,20-lf);
  }
  printf(1,"Assignment states 3-frame expected counts: FIFO=15, LRU=12. Verify run output.\\n");
  exit();
}
