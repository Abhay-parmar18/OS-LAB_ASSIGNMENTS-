#include "types.h"
#include "stat.h"
#include "user.h"

/* Q1: Requires the vmprint() kernel system call. */
int
main(void)
{
  printf(1, "Q1: page table at startup\\n");
  vmprint();
  printf(1, "Q1: after sbrk(4 * 4096)\\n");
  if(sbrk(4 * 4096) == (char*)-1){
    printf(2, "pttest: sbrk failed\\n");
    exit();
  }
  vmprint();
  exit();
}
