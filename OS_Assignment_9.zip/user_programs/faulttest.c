#include "types.h"
#include "stat.h"
#include "user.h"

/* Q2: Requires lazy allocation and getfaults() in the kernel. */
int
main(void)
{
  char *p;
  int pid, faults;
  printf(1, "Q2: lazy allocation test\\n");
  printf(1, "fault count before = %d\\n", getfaults());
  p = sbrk(32 * 4096);
  if(p == (char*)-1){
    printf(2, "faulttest: sbrk failed\\n");
    exit();
  }
  /* Exactly five distinct pages are touched. */
  p[0 * 4096] = 1;
  p[3 * 4096] = 2;
  p[7 * 4096] = 3;
  p[15 * 4096] = 4;
  p[31 * 4096] = 5;
  faults = getfaults();
  printf(1, "faults after five first-touch writes = %d (expected 5)\\n", faults);
  pid = fork();
  if(pid < 0){
    printf(2, "fork failed\\n");
    exit();
  }
  if(pid == 0){
    printf(1, "child: testing invalid address\\n");
    *(volatile char*)0x70000000 = 9;
    printf(1, "ERROR: invalid access survived\\n");
    exit();
  }
  wait();
  printf(1, "parent survived invalid child access\\n");
  exit();
}
