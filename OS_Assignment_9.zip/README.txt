OS Assignment 9 — xv6 x86 starter package

Included:
- user_programs/pttest.c
- user_programs/faulttest.c
- user_programs/pagerepl.c
- report/Report_Draft.txt
- results/Results_Worksheet.txt

The PDF asks for kernel changes to vm.c, trap.c, proc.h, sysproc.c, syscall.c,
syscall.h, defs.h, user.h and usys.S as needed. This archive does not contain
a complete xv6 source tree or verified kernel patch because no xv6 source tree
was provided.

Integration:
1. Copy the three .c programs into the xv6-public (x86) source root.
2. Add _pttest, _faulttest and _pagerepl to UPROGS in Makefile.
3. Add vmprint() and getfaults() syscall declarations/stubs/table entries.
4. Implement vmprint() in vm.c; lazy allocation and fault counting in trap.c,
   sysproc.c, proc.h, and make vm.c skip absent pages in deallocuvm/copyuvm.
5. Build and run in QEMU. Capture actual terminal screenshots.
6. Fill in Results_Worksheet.txt from actual output; don't present predicted
   results as actual screenshots.

The assignment PDF specifies FIFO=15 and LRU=12 for 3 frames. Verify those
values by running the provided simulation and investigate any discrepancy.
