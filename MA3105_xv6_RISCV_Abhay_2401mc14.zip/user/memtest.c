#include "kernel/types.h"
#include "user/user.h"

volatile int global_variable = 123;

int
main(void)
{
  char *p;
  int before, after_alloc, pid, status;
  int va;

  before = freepages();
  printf("free pages at start: %d\n", before);

  p = sbrk(10 * 4096);
  if(p == (char*)-1) {
    printf("sbrk failed\n");
    exit(1);
  }
  after_alloc = freepages();
  printf("free pages after sbrk(10 pages): %d\n", after_alloc);

  va = (int)&global_variable;
  printf("global VA: 0x%x, PA: 0x%x\n", va, va2pa(va));
  printf("va2pa(0x7fffffff): %d\n", va2pa(0x7fffffff));

  pid = fork();
  if(pid < 0) {
    printf("fork failed\n");
    exit(1);
  }
  if(pid == 0) {
    printf("child global VA: 0x%x, PA: 0x%x\n",
           (int)&global_variable, va2pa((int)&global_variable));
    exit(0);
  }

  printf("free pages after fork: %d\n", freepages());
  printf("parent global VA: 0x%x, PA: 0x%x\n",
         (int)&global_variable, va2pa((int)&global_variable));
  wait(&status);
  printf("free pages after child exit + wait: %d\n", freepages());
  exit(0);
}
