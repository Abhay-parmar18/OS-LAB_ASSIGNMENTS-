#include "kernel/types.h"
#include "user/user.h"

/* Expected sequence: ABCABCABCABCABC */
int
main(void)
{
  int pid, i;

  if(sem_init(0, 1) < 0 ||
     sem_init(1, 0) < 0 ||
     sem_init(2, 0) < 0) {
    printf("sem_init failed\n");
    exit(1);
  }

  pid = fork();
  if(pid < 0) { printf("fork failed\n"); exit(1); }
  if(pid == 0) {
    for(i = 0; i < 5; i++) {
      sem_wait(0);
      printf("A");
      sem_post(1);
    }
    exit(0);
  }

  pid = fork();
  if(pid < 0) { printf("fork failed\n"); exit(1); }
  if(pid == 0) {
    for(i = 0; i < 5; i++) {
      sem_wait(1);
      printf("B");
      sem_post(2);
    }
    exit(0);
  }

  pid = fork();
  if(pid < 0) { printf("fork failed\n"); exit(1); }
  if(pid == 0) {
    for(i = 0; i < 5; i++) {
      sem_wait(2);
      printf("C");
      sem_post(0);
    }
    exit(0);
  }

  for(i = 0; i < 3; i++)
    wait(0);
  printf("\nDone\n");
  exit(0);
}
