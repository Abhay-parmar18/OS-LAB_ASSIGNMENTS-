#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "spinlock.h"

/*
 * Kernel counting semaphores for the MA3105 xv6-RISC-V adaptation.
 * IDs: 0..7. A semaphore is shared by processes because it lives in
 * the kernel, not in a process address space.
 */
#define NSEMS 8

struct ksemaphore {
  int value;
  int used;
  struct spinlock lock;
};

static struct ksemaphore sems[NSEMS];
static struct spinlock semtable_lock;

void
sem_init_table(void)
{
  int i;
  initlock(&semtable_lock, "semtable");
  for(i = 0; i < NSEMS; i++) {
    sems[i].value = 0;
    sems[i].used = 0;
    initlock(&sems[i].lock, "semaphore");
  }
}

/* Called by the syscall handlers. */
int
ksem_init(int id, int value)
{
  if(id < 0 || id >= NSEMS || value < 0)
    return -1;

  acquire(&semtable_lock);
  acquire(&sems[id].lock);
  sems[id].value = value;
  sems[id].used = 1;
  release(&sems[id].lock);
  release(&semtable_lock);
  return 0;
}

int
ksem_wait(int id)
{
  struct ksemaphore *s;

  if(id < 0 || id >= NSEMS)
    return -1;
  s = &sems[id];

  acquire(&s->lock);
  if(!s->used) {
    release(&s->lock);
    return -1;
  }
  while(s->value == 0)
    sleep(s, &s->lock);
  s->value--;
  release(&s->lock);
  return 0;
}

int
ksem_post(int id)
{
  struct ksemaphore *s;

  if(id < 0 || id >= NSEMS)
    return -1;
  s = &sems[id];

  acquire(&s->lock);
  if(!s->used) {
    release(&s->lock);
    return -1;
  }
  s->value++;
  wakeup(s);
  release(&s->lock);
  return 0;
}
