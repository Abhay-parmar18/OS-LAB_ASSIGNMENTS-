MA3105 Operating System Lab - xv6-RISC-V adaptation

Student: Abhay Singh Parmar
Roll number: 2401MC14
Questions:
Q1. Counting semaphores and strict A-B-C process synchronization.
Q2. Free physical page count and user virtual-to-physical translation.



After integration:
  make clean
  make qemu

Inside xv6:
  synctest
  memtest

Expected synctest output:
  ABCABCABCABCABC
  Done

The memory test should show a lower free-page count after allocating memory,
return -1 for an unmapped address, and show the same global virtual address
but different parent/child physical addresses after fork.

Validate all output on your own tree. Small differences between xv6-riscv
versions may require adapting syscall signatures and Makefile formatting.
