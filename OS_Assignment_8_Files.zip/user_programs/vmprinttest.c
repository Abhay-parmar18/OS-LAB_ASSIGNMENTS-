#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  char *p;

  printf(1, "Q3: Page table at startup\n");
  vmprint();

  printf(1, "Q3: Grow heap by 8 pages\n");
  p = sbrk(8 * 4096);
  if(p == (char*)-1){
    printf(2, "sbrk growth failed\n");
    exit();
  }
  p[0] = 1;
  p[7 * 4096] = 2;
  vmprint();

  printf(1, "Q3: Shrink heap by one page\n");
  if(sbrk(-4096) == (char*)-1)
    printf(2, "sbrk shrink failed\n");
  vmprint();

  exit();
}
