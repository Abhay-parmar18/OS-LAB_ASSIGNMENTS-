#include "types.h"
#include "stat.h"
#include "user.h"

struct meminfo {
  int total_pages;
  int free_pages;
  int process_pages;
  int page_table_pages;
};

static void
showmem(char *label)
{
  struct meminfo mi;
  if(getmeminfo(&mi) < 0){
    printf(2, "getmeminfo failed at %s\n", label);
    return;
  }
  printf(1, "%s: total=%d free=%d process=%d page-table=%d\n",
         label, mi.total_pages, mi.free_pages,
         mi.process_pages, mi.page_table_pages);
}

int
main(void)
{
  char *p;
  int pid;

  printf(1, "Q4: Lazy heap allocation test\n");
  showmem("before sbrk");

  p = sbrk(32 * 1024 * 1024);
  if(p == (char*)-1){
    printf(2, "large sbrk failed\n");
    exit();
  }
  printf(1, "reserved 32 MB; touching only selected pages\n");
  showmem("after sbrk before touches");

  p[0] = 11;
  p[8 * 1024 * 1024] = 22;
  p[24 * 1024 * 1024] = 33;
  showmem("after touching three pages");

  pid = fork();
  if(pid < 0){
    printf(2, "fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "child touching another lazy page\n");
    p[16 * 1024 * 1024] = 44;
    exit();
  }
  wait();
  showmem("after child exit");

  /* Exercise a system call using a buffer in a lazily allocated page. */
  p[31 * 1024 * 1024] = 'X';
  printf(1, "buffer byte=%c\n", p[31 * 1024 * 1024]);
  exit();
}
