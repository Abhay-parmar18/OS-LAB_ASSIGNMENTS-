#include "types.h"
#include "stat.h"
#include "user.h"

struct meminfo {
  int total_pages;
  int free_pages;
  int process_pages;
  int page_table_pages;
};

static void
showmem(char *label)
{
  struct meminfo mi;

  if(getmeminfo(&mi) < 0){
    printf(2, "getmeminfo failed at %s\n", label);
    return;
  }
  printf(1, "%s: total=%d free=%d process=%d page-table=%d\n",
         label, mi.total_pages, mi.free_pages,
         mi.process_pages, mi.page_table_pages);
}

int
main(void)
{
  char *p;
  int pid;

  printf(1, "Q2: Physical memory statistics\n");
  showmem("initial");

  p = sbrk(8 * 4096);
  if(p == (char*)-1){
    printf(2, "sbrk failed\n");
    exit();
  }
  p[0] = 1;
  p[4 * 4096] = 2;
  showmem("after allocation/touch");

  pid = fork();
  if(pid < 0){
    printf(2, "fork failed\n");
    exit();
  }
  if(pid == 0){
    showmem("child");
    exit();
  }
  wait();
  showmem("after child reaped");
  exit();
}
