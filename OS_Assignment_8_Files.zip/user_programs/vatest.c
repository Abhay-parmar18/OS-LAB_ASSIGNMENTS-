#include "types.h"
#include "stat.h"
#include "user.h"

int global_var = 12345;

int
main(void)
{
  int local_var = 6789;
  char *heap_var;
  int pa;
  int pid;

  printf(1, "Q1: Virtual-to-physical address translation\n");
  printf(1, "global_var VA = %p\n", &global_var);
  pa = va2pa((int)&global_var);
  printf(1, "global_var PA = %d\n", pa);

  printf(1, "local_var VA = %p\n", &local_var);
  pa = va2pa((int)&local_var);
  printf(1, "local_var PA = %d\n", pa);

  heap_var = malloc(4096);
  if(heap_var == 0){
    printf(2, "malloc failed\n");
    exit();
  }
  heap_var[0] = 'A';
  printf(1, "heap_var VA = %p\n", heap_var);
  pa = va2pa((int)heap_var);
  printf(1, "heap_var PA = %d\n", pa);

  printf(1, "invalid VA 0x7fffffff -> %d (expected -1)\n",
         va2pa(0x7fffffff));

  pid = fork();
  if(pid < 0){
    printf(2, "fork failed\n");
    free(heap_var);
    exit();
  }
  if(pid == 0){
    printf(1, "child: global VA = %p, PA = %d\n",
           &global_var, va2pa((int)&global_var));
    exit();
  }
  wait();
  printf(1, "parent: global VA = %p, PA = %d\n",
         &global_var, va2pa((int)&global_var));

  free(heap_var);
  exit();
}
