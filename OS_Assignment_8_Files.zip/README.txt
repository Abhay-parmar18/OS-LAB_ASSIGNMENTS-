OS Lab Assignment 8 — xv6 Memory Management
===========================================

Included:
- user_programs/vatest.c      (Question 1)
- user_programs/memtest.c     (Question 2)
- user_programs/vmprinttest.c (Question 3)
- user_programs/lazytest.c    (Question 4)

Important limitations:
1. The uploaded assignment PDF only gives detailed specifications for Questions 1–4.
   Its common submission section mentions cowtest.c, protecttest.c, shmtest.c, and
   pagerepl.c for Questions 5–8, but their actual question statements are absent.
2. These are user-level test programs, not a complete, verified xv6 kernel patch.
   They require the corresponding system calls and struct definitions to be
   implemented in your xv6 x86 source tree.
3. This assignment describes xv6 x86 (two-level paging, PTE_U, KERNBASE). Do not
   use these unchanged in xv6-riscv.

Integration checklist (xv6-public / x86):
- Copy the four .c files into the xv6 source root (not just this folder).
- Add their names to UPROGS in Makefile (e.g. _vatest, _memtest,
  _vmprinttest, _lazytest).
- Add user declarations in user.h:
    int va2pa(int);
    int getmeminfo(struct meminfo *);
    int vmprint(void);
  Put the meminfo definition in a shared header included consistently by
  kernel and user code, or use the exact layout required by your implementation.
- Add syscall numbers and entries in syscall.h, syscall.c, usys.S, and implement
  the kernel handlers. Expose the matching declarations in defs.h as needed.
- Implement and test kernel changes against the exact xv6 baseline you use.
- Build and run each test in QEMU; save terminal screenshots showing the actual
  output. Do not submit fabricated screenshots or expected output as actual runs.

Implementation notes:
- va2pa must reject non-present entries and entries without PTE_U, and the
  physical address should include the page offset.
- getmeminfo's page counts and the definition of "page-table pages" must be
  consistent with your kernel implementation.
- vmprint should avoid printing kernel mappings as user mappings and should
  identify the guard page by its present bit and cleared PTE_U bit.
- Lazy allocation affects trap handling, copyuvm(), shrinking, and kernel
  copyin/copyout paths. A basic sbrk-only change is not enough.

Suggested test/build sequence:
  make clean
  make qemu-nox
  # at the xv6 shell:
  vatest
  memtest
  vmprinttest
  lazytest

If your xv6 Makefile uses a different QEMU target, use the target provided by
your checkout.

Before submission, verify that the kernel compiles cleanly, every test passes,
and the report describes your actual implementation and observed outputs.
