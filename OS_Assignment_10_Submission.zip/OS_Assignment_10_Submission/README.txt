OS ASSIGNMENT 10 — SUBMISSION PACKAGE

Contents
--------
user/memtest.c       Q1 physical memory statistics test
user/vttest.c        Q2 virtual-to-physical translation test
user/pagetest.c      Q3 page-table and read-only protection test
user/pagereplace.c   Q4 FIFO, LRU and Optimal simulation
kernel/kernel_changes_guide.txt
                     Kernel integration snippets and build instructions
REPORT_TEMPLATE.txt Short report template

Target
------
The syscall integration guide targets the traditional 32-bit x86 xv6-public
teaching OS. It is not a complete kernel source tree. Copy the four C files
into the xv6-public directory and add them to Makefile's UPROGS list. Apply
the kernel changes from kernel/kernel_changes_guide.txt to your own source.

Build and run
-------------
1. Back up your xv6 source directory.
2. Copy user/*.c into the xv6-public source directory.
3. Apply the kernel syscall and VM changes in the guide.
4. Add _memtest, _vttest, _pagetest and _pagereplace to UPROGS in Makefile.
5. Run: make clean && make
6. Run: make qemu-nox
7. At the xv6 shell, run memtest, vttest, pagetest and pagereplace.
8. Capture your own terminal screenshots and complete REPORT_TEMPLATE.txt.

Important limitations / checks
------------------------------
- The uploaded assignment does not specify an xv6 source revision. The
  integration guide therefore targets xv6-public x86 and may need small
  adjustments for a different fork.
- The kernel snippets are integration code, not complete replacements for
  kalloc.c, vm.c or syscall files.
- Physical memory counters are enabled after boot-time free-list setup so
  initialization is not counted as runtime frees.
- The page protection test performs the invalid write in a child process.
- memstats() prints statistics in the kernel; it does not return a structure.
- Verify all outputs in your own xv6 build before submission.
