// Q1: Physical memory allocation statistics
#include "types.h"
#include "stat.h"
#include "user.h"

#define PAGE_SIZE 4096

int
main(void)
{
  char *p;

  printf(1, "\n===== Memory statistics: before allocation =====\n");
  memstats();

  p = sbrk(2 * PAGE_SIZE);
  if(p == (char*)-1){
    printf(2, "memtest: sbrk failed\n");
    exit();
  }

  // Touch both pages so that the allocator must provide physical pages.
  p[0] = 'A';
  p[PAGE_SIZE] = 'B';

  printf(1, "\n===== Memory statistics: after allocating 2 pages =====\n");
  memstats();

  if(sbrk(-2 * PAGE_SIZE) == (char*)-1){
    printf(2, "memtest: unable to release memory\n");
    exit();
  }

  printf(1, "\n===== Memory statistics: after releasing memory =====\n");
  memstats();

  exit();
}
