// Q4: FIFO, LRU and Optimal page replacement
#include "types.h"
#include "stat.h"
#include "user.h"

#define NREF 20
#define MAXF 5

int refs[NREF] = {
  7, 0, 1, 2, 0, 3, 0, 4, 2, 3,
  0, 3, 2, 1, 2, 0, 1, 7, 0, 1
};

int
contains(int frames[], int n, int page)
{
  int i;
  for(i = 0; i < n; i++)
    if(frames[i] == page)
      return i;
  return -1;
}

void
printframes(int frames[], int n)
{
  int i;
  printf(1, "[ ");
  for(i = 0; i < n; i++){
    if(frames[i] == -1)
      printf(1, "- ");
    else
      printf(1, "%d ", frames[i]);
  }
  printf(1, "]");
}

void
run_fifo(int nf)
{
  int frames[MAXF], i, pos, faults, hits, next;
  for(i = 0; i < nf; i++) frames[i] = -1;
  pos = faults = hits = next = 0;

  printf(1, "\nFIFO with %d frames\n", nf);
  for(i = 0; i < NREF; i++){
    if(contains(frames, nf, refs[i]) >= 0){
      hits++;
      printf(1, "%d: HIT  ", refs[i]);
    } else {
      faults++;
      frames[pos] = refs[i];
      pos = (pos + 1) % nf;
      printf(1, "%d: FAULT ", refs[i]);
    }
    printframes(frames, nf);
    printf(1, "\n");
  }
  printf(1, "FIFO summary: faults=%d hits=%d hit_ratio=%d%% fault_ratio=%d%%\n",
         faults, hits, hits * 100 / NREF, faults * 100 / NREF);
}

void
run_lru(int nf)
{
  int frames[MAXF], last[MAXF];
  int i, j, idx, victim, oldest, faults, hits;

  for(i = 0; i < nf; i++){
    frames[i] = -1;
    last[i] = -1;
  }
  faults = hits = 0;

  printf(1, "\nLRU with %d frames\n", nf);
  for(i = 0; i < NREF; i++){
    idx = contains(frames, nf, refs[i]);
    if(idx >= 0){
      hits++;
      last[idx] = i;
      printf(1, "%d: HIT  ", refs[i]);
    } else {
      faults++;
      victim = -1;
      for(j = 0; j < nf; j++)
        if(frames[j] == -1){ victim = j; break; }

      if(victim < 0){
        oldest = 0;
        for(j = 1; j < nf; j++)
          if(last[j] < last[oldest]) oldest = j;
        victim = oldest;
      }
      frames[victim] = refs[i];
      last[victim] = i;
      printf(1, "%d: FAULT ", refs[i]);
    }
    printframes(frames, nf);
    printf(1, "\n");
  }
  printf(1, "LRU summary: faults=%d hits=%d hit_ratio=%d%% fault_ratio=%d%%\n",
         faults, hits, hits * 100 / NREF, faults * 100 / NREF);
}

void
run_optimal(int nf)
{
  int frames[MAXF], i, j, k, idx, victim, farthest, nextuse;
  int faults, hits;

  for(i = 0; i < nf; i++) frames[i] = -1;
  faults = hits = 0;

  printf(1, "\nOptimal with %d frames\n", nf);
  for(i = 0; i < NREF; i++){
    idx = contains(frames, nf, refs[i]);
    if(idx >= 0){
      hits++;
      printf(1, "%d: HIT  ", refs[i]);
    } else {
      faults++;
      victim = -1;
      for(j = 0; j < nf; j++)
        if(frames[j] == -1){ victim = j; break; }

      if(victim < 0){
        farthest = -1;
        for(j = 0; j < nf; j++){
          nextuse = NREF + 1;
          for(k = i + 1; k < NREF; k++)
            if(refs[k] == frames[j]){
              nextuse = k;
              break;
            }
          if(nextuse > farthest){
            farthest = nextuse;
            victim = j;
          }
        }
      }
      frames[victim] = refs[i];
      printf(1, "%d: FAULT ", refs[i]);
    }
    printframes(frames, nf);
    printf(1, "\n");
  }
  printf(1, "Optimal summary: faults=%d hits=%d hit_ratio=%d%% fault_ratio=%d%%\n",
         faults, hits, hits * 100 / NREF, faults * 100 / NREF);
}

int
main(void)
{
  int nf;
  printf(1, "Reference string: ");
  for(nf = 0; nf < NREF; nf++)
    printf(1, "%d ", refs[nf]);
  printf(1, "\n");

  for(nf = 3; nf <= 5; nf++){
    run_fifo(nf);
    run_lru(nf);
    run_optimal(nf);
  }
  exit();
}
