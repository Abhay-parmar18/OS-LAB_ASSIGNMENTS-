// Q2: Virtual-to-physical address translation
#include "types.h"
#include "stat.h"
#include "user.h"

#define PAGE_SIZE 4096

int
main(void)
{
  char *p;
  int pa;
  int badva;

  p = sbrk(2 * PAGE_SIZE);
  if(p == (char*)-1){
    printf(2, "vttest: sbrk failed\n");
    exit();
  }

  // Touch the pages so they are backed by physical memory.
  p[0] = 'X';
  p[PAGE_SIZE] = 'Y';

  printf(1, "Allocated virtual range: 0x%x - 0x%x\n",
         (uint)p, (uint)(p + 2 * PAGE_SIZE - 1));

  pa = vtop((int)(uint)p);
  if(pa < 0)
    printf(1, "Translation failed for 0x%x\n", (uint)p);
  else
    printf(1, "VA 0x%x -> PA 0x%x\n", (uint)p, pa);

  pa = vtop((int)(uint)(p + PAGE_SIZE));
  if(pa < 0)
    printf(1, "Translation failed for second page\n");
  else
    printf(1, "VA 0x%x -> PA 0x%x\n", (uint)(p + PAGE_SIZE), pa);

  // Address zero is normally unmapped in xv6.
  badva = 0;
  pa = vtop(badva);
  if(pa < 0)
    printf(1, "Correctly rejected invalid/unmapped VA 0x%x\n", badva);
  else
    printf(1, "Unexpected mapping: VA 0x%x -> PA 0x%x\n", badva, pa);

  sbrk(-2 * PAGE_SIZE);
  exit();
}
