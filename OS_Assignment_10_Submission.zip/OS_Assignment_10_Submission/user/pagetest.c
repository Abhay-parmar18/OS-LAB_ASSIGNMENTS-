// Q3: Page-table inspection and read-only protection
#include "types.h"
#include "stat.h"
#include "user.h"

#define PAGE_SIZE 4096

int
main(void)
{
  volatile char *p;
  int pid;

  p = (volatile char*)sbrk(PAGE_SIZE);
  if(p == (char*)-1){
    printf(2, "pagetest: sbrk failed\n");
    exit();
  }

  // Ensure that the page is allocated and mapped.
  p[0] = 'R';

  printf(1, "\nBefore changing permissions:\n");
  pageinfo((int)(uint)p);

  if(setreadonly((int)(uint)p) < 0){
    printf(2, "pagetest: setreadonly failed\n");
    exit();
  }

  printf(1, "\nAfter removing write permission:\n");
  pageinfo((int)(uint)p);

  // Perform the illegal write in a child. The page fault should kill the
  // child, while the parent remains alive to print the result.
  pid = fork();
  if(pid < 0){
    printf(2, "pagetest: fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "Child: attempting to write to read-only page...\n");
    p[0] = 'W';
    printf(1, "ERROR: write unexpectedly succeeded\n");
    exit();
  }

  wait();
  printf(1, "Parent: child has exited; a protection fault was expected.\n");
  exit();
}
